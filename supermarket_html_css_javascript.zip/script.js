const products = [
  ["01", "Fresh Tomatoes", "Fruits & Vegetables", 50, 10, "01-fresh-tomatoes.svg"],
  ["02", "Fresh Apples", "Fruits", 180, 6, "02-fresh-apples.svg"],
  ["03", "Bananas", "Fruits", 60, 10, "03-bananas.svg"],
  ["04", "Fresh Milk", "Dairy", 32, 10, "04-fresh-milk.svg"],
  ["05", "Basmati Rice", "Grains", 650, 10, "05-basmati-rice.svg"],
  ["06", "Wheat Flour", "Grains", 280, 8, "06-wheat-flour.svg"],
  ["07", "Cooking Oil", "Oils", 145, 5, "07-cooking-oil.svg"],
  ["08", "Biscuits", "Snacks", 30, 15, "08-biscuits.svg"],
  ["09", "Potato Chips", "Snacks", 20, 12, "09-potato-chips.svg"],
  ["10", "Tea Powder", "Beverages", 250, 2, "10-tea-powder.svg"],
  ["11", "Mineral Water", "Beverages", 20, 20, "11-mineral-water.svg"],
  ["12", "Carrots", "Vegetables", 70, 8, "12-carrots.svg"],
  ["13", "Curd", "Dairy", 35, 8, "13-curd.svg"],
  ["14", "Spices", "Grocery", 120, 5, "14-spices.svg"],
  ["15", "Cleaning Soap", "Cleaning", 55, 12, "15-cleaning-soap.svg"],
  ["16", "Sugar", "Grocery", 48, 5, "16-sugar.svg"],
  ["17", "Salt", "Grocery", 28, 5, "17-salt.svg"],
  ["18", "Toor Dal", "Pulses", 180, 3, "18-toor-dal.svg"],
  ["19", "Moong Dal", "Pulses", 150, 3, "19-moong-dal.svg"],
  ["20", "Chana Dal", "Pulses", 120, 3, "20-chana-dal.svg"],
  ["21", "Coffee", "Beverages", 320, 2, "21-coffee.svg"],
  ["22", "Butter", "Dairy", 58, 5, "22-butter.svg"],
  ["23", "Cheese", "Dairy", 120, 4, "23-cheese.svg"],
  ["24", "Bread", "Bakery", 45, 10, "24-bread.svg"],
  ["25", "Noodles", "Instant Food", 15, 20, "25-noodles.svg"],
  ["26", "Tomato Ketchup", "Sauces", 110, 5, "26-tomato-ketchup.svg"],
  ["27", "Jam", "Spreads", 140, 4, "27-jam.svg"],
  ["28", "Toothpaste", "Personal Care", 95, 8, "28-toothpaste.svg"],
  ["29", "Toothbrush", "Personal Care", 60, 10, "29-toothbrush.svg"],
  ["30", "Bath Soap", "Personal Care", 55, 12, "30-bath-soap.svg"],
  ["31", "Shampoo", "Personal Care", 120, 6, "31-shampoo.svg"],
  ["32", "Hand Wash", "Personal Care", 110, 7, "32-hand-wash.svg"],
  ["33", "Laundry Detergent", "Cleaning", 210, 5, "33-laundry-detergent.svg"],
  ["34", "Dishwash Liquid", "Cleaning", 120, 6, "34-dishwash-liquid.svg"],
  ["35", "Floor Cleaner", "Cleaning", 180, 4, "35-floor-cleaner.svg"]
];

const grid = document.getElementById("productGrid");
const searchBox = document.getElementById("searchBox");
const categoryFilter = document.getElementById("categoryFilter");
const resultCount = document.getElementById("resultCount");

const categories = [...new Set(products.map(p => p[2]))].sort();
categories.forEach(category => {
  const option = document.createElement("option");
  option.value = category;
  option.textContent = category;
  categoryFilter.appendChild(option);
});

function displayProducts() {
  const search = searchBox.value.toLowerCase().trim();
  const category = categoryFilter.value;

  const filtered = products.filter(p => {
    const matchesSearch = p[1].toLowerCase().includes(search);
    const matchesCategory = category === "all" || p[2] === category;
    return matchesSearch && matchesCategory;
  });

  grid.innerHTML = "";

  filtered.forEach(p => {
    const card = document.createElement("article");
    card.className = "product-card";
    card.innerHTML = `
      <img src="images/${p[5]}" alt="${p[1]}">
      <h3>${p[1]}</h3>
      <div class="category">${p[2]}</div>
      <div class="price">₹${p[3]}</div>
      <div class="quantity">Stock: ${p[4]}</div>
    `;
    grid.appendChild(card);
  });

  resultCount.textContent = `${filtered.length} product(s) found`;
}

searchBox.addEventListener("input", displayProducts);
categoryFilter.addEventListener("change", displayProducts);

displayProducts();
